/*
* @Change History
* Ver   Date         Author         Modification
* 1.56  03-08-2021   Shyam Goel     TS-608  Red Asterisk Mark on the Fields that are added from the Fieldset
*/
({
    doInit: function (component, event, helper) {
        // Single RMT change to get recordId.
        let params = helper.getUrlParams(window.location.href);
        if (params.hasOwnProperty("c__recordId")) {
            component.set('v.recordId', params["c__recordId"]);
        }
        console.log('RecodrId  ' +component.get("v.recordId"));
        var extraFilters = {'WOD_2__Type__c':'Retail'};
        component.set("v.defaultInvenotryFilter",extraFilters);
        component.set("v.additionalFilters",extraFilters);
        helper.callApexController(component, "isTWODLite", {
        }, false).then($A.getCallback(function (response) {
            if (response.status === true) {
                var isTWODLite = JSON.parse(response['data']);
                if(isTWODLite == true){
                    component.set("v.isFullVersion", false);
                }
                
                else{
                    helper.getConfigValues(component, event, helper);
                    helper.getUserBus(component, event, helper);
                    helper.showSpinner(component, event, 'RMTBulkSpinner');
                    component.set("v.showSpinner", true);
                    helper.initializeInventoryTransactionHistoryObject(component, event, helper);
                    helper.getInventoryTransactionHistoryFieldset(component, event, helper);
                }
                
            }
            else {
                helper.showErrorToast(component, event, '', $A.get("$Label.c.RMTBulkGenericErrorMessage"));
            }
            
        }, false)).catch(function (error) {
            
            helper.showErrorToast(component, event, '', $A.get("$Label.c.RMTBulkGenericErrorMessage"));
        });
    },

    reInit : function(component, event, helper) {
        $A.get('e.force:refreshView').fire();       
    },
    
    cancel: function (component, event, helper) {
        // Single RMT redirect change
        if(component.get("v.recordId") != null && component.get("v.recordId") != ''){
            let navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": component.get("v.recordId"),
                "slideDevName": "related"
            });
            let datareccomp = component.find("datarecord");
            if(datareccomp)
            datareccomp.reloadRecord({ skipCache: true });
            $A.get("e.force:refreshView").fire();
            navEvt.fire();
        }else{
            helper.navigateToListHelper(component, event, helper, 'WOD_2__Inventory__c', component.get("v.inventoryListView"));
        }
    },
    
    //set Transaction History on enter
    setInventoryTransactionHistoryValues: function (component, event, helper) {
        var inventoryHistoryTransactionObj = component.get("v.transferDetails");
        var sourceVal = event.getSource();
        var sourceApiName = sourceVal.get("v.fieldName");
        var sourceValue = sourceVal.get('v.value');
        inventoryHistoryTransactionObj[sourceApiName] = sourceValue;
        component.set("v.transferDetails", inventoryHistoryTransactionObj);
        
    },
    
    setSelectedDealer: function (component, event, helper) {
        var selectedDealer = event.getParam("selectedRecord");
        component.set("v.selectedDealer", selectedDealer);
        //component.set("v.selectedDealerId", selectedDealer.Id);
        console.log('dealer id ********** 1   ',component.get("v.selectedDealerId"))
    },
    lookupValueRemoved: function (component, event, helper) { 
        var lookupComponentId = event.getParam('lookupComponentId');
        if(lookupComponentId === 'rmtDealerLookupId'){
            component.set('v.displayAccountDetailView',false);
        }
        if(lookupComponentId === 'businessUnitLookupId'){
            var action = component.get('c.handleClearSearchResults');
            $A.enqueueAction(action);
            component.set("v.additionalFilters",component.get("v.defaultInvenotryFilter"));
            component.set("v.isBUselected",false);
        }
    },
    setSelectedCustomerfromLookup: function (component, event, helper) {
        var lookupComponentId = event.getParam('lookupComponentId');
        if(lookupComponentId === 'rmtDealerLookupId'){
            var selectedDealer = event.getParam("selectedObject");
            component.set('v.displayAccountDetailView',false);
            //console.log('selectd dealer ********** ',JOSN.Stringify    (selectedDealer))
            var inventoryHistoryTransactionObj = component.get("v.transferDetails");
            // For Account Business Category Configuration Look Up 
            if(component.get("v.accountBUcheck")){
                component.set("v.selectedDealer", selectedDealer);
                component.set("v.selectedDealerId", selectedDealer.Id);
                component.set('v.displayAccountDetailView',true);
                console.log('dealer id ********** 2  ',component.get("v.selectedDealerId"))
                //inventoryHistoryTransactionObj["WOD_2__To__c"] = selectedDealer.Id;            
                inventoryHistoryTransactionObj["WOD_2__To__c"] = selectedDealer; 
            }else{
                component.set("v.selectedDealer", selectedDealer.WOD_2__Account__r);
                component.set("v.selectedDealerId", selectedDealer.WOD_2__Account__r.Id);
                component.set('v.displayAccountDetailView',true);
                console.log('dealer id ********** 2  ',component.get("v.selectedDealerId"))
                //inventoryHistoryTransactionObj["WOD_2__To__c"] = selectedDealer.Id;            
                inventoryHistoryTransactionObj["WOD_2__To__c"] = selectedDealer.WOD_2__Account__r;
            }
            //end
            component.set("v.transferDetails", inventoryHistoryTransactionObj);           
        }
        if (lookupComponentId === 'businessUnitLookupId') {
            var selectedBusinessUnit = event.getParam("selectedObject");
            var id = selectedBusinessUnit.Id;
            component.set("v.selectedBusinessUnit",id);
            var extraFilters = component.get("v.defaultInvenotryFilter")
            extraFilters.WOD_2__Business_Unit__c = id;
            component.set("v.additionalFilters",extraFilters);
            return helper.callApexController(component, "getBusinessUnitConfigs", {
                businessCategoryConfigName : component.get("v.selectedBUValue"),
                bccsNameList : component.get("v.requiredBCCS")
            }).then($A.getCallback(function (response) {
                if (response.data) {
                    var responseData = JSON.parse(response.data);
                    for (var buConfig in responseData){
                        if(buConfig === 'BulkRMT_AccountDetailSharingSetting'){
                            component.set("v.accountDetailSharingSetting" , responseData[buConfig]);
                        } else if(buConfig === 'BulkRMT_AccountDetailColumnSize'){
                            component.set("v.accountDetailColumnSize" , responseData[buConfig]);
                        } else if(buConfig === 'BulkRMT_TransferDateMandatory'){
                            component.set("v.transferDateMandatory" , responseData[buConfig]);
                        } else if(buConfig === 'BulkRMT_CommentsMandatory'){
                            component.set("v.commentsMandatory" , responseData[buConfig]);
                        }else if (buConfig === 'BulkRMT_SearchAttributes') {
                            component.set("v.inventorySearchAttributesToShow", responseData[buConfig]);
                        } else if (buConfig === 'BulkRMT_InventoryHeaderFieldSet') {
                            component.set("v.InventoryListingHeader", responseData[buConfig]);
                        }else if (buConfig === 'BulkRMT_OverrideClassName') {
                            component.set("v.BulkRMTOverrideClass", responseData[buConfig]);
                        }     
                    }
                    component.set("v.isBUselected",true);
                }
            })).catch(function (error) {
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                helper.showErrorMessage(component, event, helper, error);
            });
        }
    },
    
    filterConditionCaptureHandler: function (component, event, helper) {
        var filterCriteria = event.getParam("filterCriteria");
        var filterLogic = event.getParam("filterLogic");
        // Show modal only when there is any change to filter logic or filter criteria
        if (component.get("v.batchInsert") === true || filterLogic !== component.get("v.filterLogic") || filterCriteria !== component.get("v.filterCriteria")) {
            component.set("v.filterLogic", filterLogic);
            component.set("v.filterCriteria", filterCriteria);
            helper.handleWarningModal(component, event, helper);
        } else {
            helper.showInfoToast(component, event, '', $A.get("$Label.c.BulkRMTwhereClauseChange"));
        }
    },
    handleBUchange: function (component, event, helper) {
       helper.handleBUchange(component,event,helper);
    },
    
    submitBulkRMT: function (component, event, helper) {
        event.preventDefault();
        // allValid will validates mandatory fields from fieldset and for the custom lookup
        var allValid =true;
        var arrayofAuraId=['lookupValue','inputFields'];
        for(var i=0;i<arrayofAuraId.length;i++){
           allValid= (helper.validateFormFields(component, arrayofAuraId[i])&& allValid);
        }
        if (allValid) {
            helper.validatethefields(component, event, helper);
        }
    },
    
    handleConfirmBulkRMT: function (component, event, helper) {
        if (component.get("v.confirmBulkRMT") !== '') {
            helper.getWhereCondition(component, event, helper);
        }
    },
    
    handleModalButtonConfirm: function (component, event, helper) {
        if (component.get("v.batchInsertConfirmed") !== '') {
            var transferDetails = component.get("v.transferDetails");
            var toDealer = component.get("v.selectedDealer.Id");
            var rmtStatus = component.get('v.inventoryTransactionHistStatus')[0];
            var whereClause = component.get("v.whereClause");
            var fieldListFromFieldSet = component.get("v.inventoryTransactionHistoryFieldsToShow");
            var fieldListFromFieldSetObject = {};
            for (var count in fieldListFromFieldSet) {
                fieldListFromFieldSetObject[fieldListFromFieldSet[count]] = transferDetails[fieldListFromFieldSet[count]];
            }
            var bulkRMTBatchAttributeObj = {
                'toDealer': toDealer,
                'rmtStatus': rmtStatus,
                'whereClause': whereClause
            };
            component.set("v.batchInsert", true);
            helper.showSpinner(component, event, 'RMTBulkSpinner');
            helper.callApexController(component, "bulkRMTBatchInsert", {
                'bulkRMTBatchTxnInput': JSON.stringify(bulkRMTBatchAttributeObj),
                'fieldListFromFieldSetObject': JSON.stringify(fieldListFromFieldSetObject)
                
            }).then(function (response) {
                helper.showInfoToast(component, event, '', $A.get('$Label.c.BulkRMT_BatchSubmissionSuccessful'));
                component.set("v.readOnlyMode",true);
            }).catch(function (error) {
                helper.showErrorToast(component, event, '', error.errormessage);
            }).finally(function () {
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                helper.navigateToListHelper(component, event, helper, 'WOD_2__Inventory__c', component.get("v.inventoryListView"));
            });
        }
    },
    getRowsFromLWC: function (component, event, helper) {
        var rows = event.getParam('value');
        if(rows.length > 0){
            component.set("v.selectedRows",rows);
        }
        
    },
    searchMethodInitialized: function (component, event, helper) {
        var whereClauseAndRecordLength = event.getParam('value');
        component.set("v.whereClause", whereClauseAndRecordLength["whereClause"]);
        component.set("v.inventoryCount", whereClauseAndRecordLength["recordsLength"]);
        var records = JSON.parse(whereClauseAndRecordLength["records"])
        if (component.get('v.inventoryCount') > parseInt(component.get('v.RMTRecordsLimit'))) {
            component.set('v.hideTableComponent',true);
            helper.validateFieldsFromModal(component, event, helper);
        }else{
            component.set('v.hideTableComponent',false);
        }
    },
    checkedselectrows: function (component, event, helper) {
        component.set("v.selectedRows",event.getParam('value'));
    },
    handleClearSearchResults: function (component, event, helper) {
        component.set("v.successRecordCount",null);
        component.set("v.TotalRecordCount",null);
        component.set("v.errorRecordCount",null);
        component.set("v.showResetButton",false);  
        component.set("v.readOnlyMode",false);
        component.set("v.inventoryCount",0);
        component.set("v.inventoryRecordList",[]);
        component.set('v.showSubmitButton',true);
        var queryBulderLWC = component.find('queryBuilderLWC');
        //added null check for queryBuilderLWC reset(TS-1010)
        if(!!queryBulderLWC){
            queryBulderLWC.handleResetSearchResult();
        }
    },
    // Single RMT data table Refresh Change.
    handleRefresh: function (component, event, helper) {
       helper.fetchInventories(component, event, helper);
    }
})