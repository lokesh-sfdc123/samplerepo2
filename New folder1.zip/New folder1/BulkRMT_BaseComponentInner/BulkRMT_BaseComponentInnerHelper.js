/*
* @Change History
* Ver   Date         Author         Modification
* 1.56  03-08-2021   Shyam Goel     TS-608  Red Asterisk Mark on the Fields that are added from the Fieldset
*/
({
    initializeInventoryTransactionHistoryObject: function (component, event, helper) {
        var transferDetails = {
            newCustomer: {},
            transferDate: '',
            latestUsageReading: '',
            selectedUsageType: '#NA',
            comments: ''
        }
        component.set("v.transferDetails", transferDetails);
    },
    
    getInventoryTransactionHistoryFieldset: function (component, event, helper) {
        helper.callApexController(component, "getFieldsetDetailsByConfigSettingHaveReadAccess",
                                  {
                                      objectName: "WOD_2__Inventory_Transaction_History__c",
                                      metadataRecordAPIName: "BulkRMT_InventoryTxnHistoryFields"
                                  }, false).then($A.getCallback(function (fieldSetResult) {
            if (fieldSetResult.data) {
                var inventoryTransactionHistoryFields = component.get("v.inventoryTransactionHistoryFieldsToShow");
                var inventoryTransactionHistoryFieldSet = JSON.parse(fieldSetResult.data);
                var inventoryTransactionHistoryObj = {};
                for (var count in inventoryTransactionHistoryFieldSet) {
                    let field = {
                        name: inventoryTransactionHistoryFieldSet[count].fieldpath,
                        required: inventoryTransactionHistoryFieldSet[count].required
                    };
                    inventoryTransactionHistoryFields.push(field);
                  //  inventoryTransactionHistoryFields.push(inventoryTransactionHistoryFieldSet[count].fieldpath);
                    inventoryTransactionHistoryObj[inventoryTransactionHistoryFieldSet[count].fieldpath] = "";
                }
                inventoryTransactionHistoryObj["WOD_2__To__c"] = "";
                component.set("v.inventoryTransactionHistoryFieldsToShow", inventoryTransactionHistoryFields);
                component.set("v.transferDetails", inventoryTransactionHistoryObj);
                helper.getDealerFieldDetails(component,event,helper);
            }
            else {
                throw helper.getErrorResponse(component, $A.get("$Label.c.RMTInventoryTransactionHistoryFieldSetError"));
            }
            component.set("v.showSpinner", false);
        })).catch(function (error) {
            component.set("v.showSpinner", false);
            helper.showErrorMessage(component, event, helper, error);
        });
    },
    
    getWhereCondition: function (component, event, helper) {
        helper.showSpinner(component, event, 'RMTBulkSpinner');
        helper.callApexController(component, "getWhereCondition", {
            "filterLogic": component.get("v.filterLogic"),
            "filterCriteria": component.get("v.filterCriteria"),
            "selectedBusinessUnit":component.get("v.selectedBusinessUnit")
        }, false).then($A.getCallback(function (response) {
            if (response.status === true) {
                var wherecondition = JSON.parse(response['data']);
                component.set("v.whereClause", wherecondition);
                helper.getInventoryRecordCount(component, event, helper);
            } else {
                throw self.getErrorResponse(component, $A.get("$Label.c.RMTBulkInvalidMessage"));
            }
        }, false)).catch(function (error) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorToast(component, event, '', $A.get("$Label.c.RMTBulkGenericErrorMessage"));
        });
    },
    
    getInventoryRecordCount: function (component, event, helper) {
        helper.callApexController(component, "getRecordsCountForCondition", {
            "whereClause": component.get("v.whereClause")
        }, false).then($A.getCallback(function (response) {
            if (response.status === true) {
                var inventoryCount = JSON.parse(response['data']);
                component.set('v.inventoryCount', inventoryCount);
                helper.checkIfInventoryCountExceededLimit(component, event, helper);
            } else {
                throw self.getErrorResponse(component, $A.get("$Label.c.RMTBulkInvalidMessage"));
            }
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
        }, false)).catch(function (error) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorToast(component, event, '', $A.get("$Label.c.RMTBulkGenericErrorMessage"));
        });
        
    },
    
    checkIfInventoryCountExceededLimit: function (component, event, helper) {
        if (component.get('v.inventoryCount') > component.get('v.RMTRecordsLimit')) {
            component.set('v.inventoryRecordList', []);
            //helper.showBatchInsertModal(component, event, helper);
            helper.validateFieldsFromModal(component, event, helper);
        } else {
            helper.fetchInventories(component, event, helper);
        }
    },
    
    handleWarningModal: function (component, event, helper) {
        // Clear the selected list here
        var selectedRecords = component.get("v.selectedRows");
        if (selectedRecords !== undefined && selectedRecords !== null && selectedRecords !== '' && selectedRecords.length > 0) {
            helper.handleSelectedListWarningModal(component, event, helper);
        } else if (component.get("v.selectedBusinessUnit") === null || component.get("v.selectedBusinessUnit") === '') {
            helper.showErrorToast(component, event, '', $A.get('$Label.c.BulkRMT_BusinessUnitMandatoryMessage'));
        } else {
            helper.getWhereCondition(component, event, helper);
        }
    },
    
    handleSelectedListWarningModal: function (component, event, helper) {
        
        $A.createComponent("c:" + "ConfirmModelComponent", {
            header: $A.get('$Label.c.RMTBulkHeader'),
            cancelLabel: $A.get('$Label.c.RMTBulkConfirmationCancel'),
            proceedLabel: $A.get('$Label.c.RMTBulkConfirmationProceed'),
            confirmMsg: $A.get('$Label.c.RMTBulkConfirmationMessage'),
            contextRecordId: 'bulkRMT',
            contextName: 'bulkRMT',
            modalHeight: '185',
            proceedPressed: component.getReference("v.confirmBulkRMT")
        },
                           function (content, status, errorMessage) {
                               if (status === "SUCCESS") {
                                   component.find("overlayLib").showCustomModal({
                                       body: content,
                                       header: $A.get('$Label.c.RMTBulkHeader'),
                                       showCloseButton: true,
                                       cssClass: "WOD_2BulkRMT_BaseComponent modalHeaderOverrideClass textHeadingOverrideClass"
                                   })
                               }
                           });
    },
    showErrorMessage: function (component, event, helper, error) {
        var errorMessage = '';
        if (error.errormessage.indexOf('FIELD_CUSTOM_VALIDATION_EXCEPTION') >= 0) {
            errorMessage = error.errormessage.split(',')[1];
            if (errorMessage.indexOf(':') >= 0) {
                errorMessage = errorMessage.split(':')[0];
            }
        } else {
            errorMessage = error.errormessage;
        }
        helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), errorMessage);
    },
    
    validatethefields: function (component, event, helper) {
        var transferDetails = component.get("v.transferDetails");
        var today = new Date().toJSON().slice(0, 10);
        var fieldListFromFieldSet = component.get("v.inventoryTransactionHistoryFieldsToShow");
        var submit = true;
        if (component.get("v.selectedRows").length === 0) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorToast(component, event, '', $A.get("$Label.c.RMTBulkNeedsSelectionofRecords"));
            submit = false;
        } else if (component.get("v.selectedDealer.Id") == null) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), $A.get("$Label.c.BulkRMTDealerEmpty"));
            submit = false;
        }
        for (var field in fieldListFromFieldSet ){
            // TWOD-3872(Transfer date and Comments BCCS Mandatory check changes)
            if(fieldListFromFieldSet[field]['name'] === 'WOD_2__Comments__c' && component.get("v.commentsMandatory") === 'TRUE' && transferDetails['WOD_2__Comments__c'].trim() === ''){ 
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), $A.get("$Label.c.BulkRMTCommentsEmpty"));
                submit = false;
            } else if(fieldListFromFieldSet[field]['name'] === 'WOD_2__Transfer_Date__c' && component.get("v.transferDateMandatory") === 'TRUE' && (transferDetails['WOD_2__Transfer_Date__c'].trim() === '' || transferDetails['WOD_2__Transfer_Date__c'] > today)){
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), $A.get("$Label.c.BulkRMTTransferDateEmptyOrFuture"));
                submit = false;
            }
        }
        helper.hideSpinner(component, event, 'RMTBulkSpinner');
        if(submit){
            helper.handlesubmit(component, event, helper);
        }
    },
    
    validateFieldsFromModal: function (component, event, helper){
        var fieldListFromFieldSet = component.get("v.inventoryTransactionHistoryFieldsToShow");
        var transferDetails = component.get("v.transferDetails");
        var today = new Date().toJSON().slice(0, 10);
        var showBatchSubmissionModal = true;
        component.set("v.batchInsert", true);
        if (component.get("v.selectedDealer.Id") == null) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), $A.get("$Label.c.BulkRMTDealerEmpty"));
            showBatchSubmissionModal = false;
        }
        for (var field in fieldListFromFieldSet ){
            if(fieldListFromFieldSet[field] === 'WOD_2__Comments__c' && component.get("v.commentsMandatory") === 'TRUE' && transferDetails['WOD_2__Comments__c'].trim() === ''){
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), $A.get("$Label.c.BulkRMTCommentsEmpty"));
                showBatchSubmissionModal = false;
            } else if(fieldListFromFieldSet[field] === 'WOD_2__Transfer_Date__c' && component.get("v.transferDateMandatory") === 'TRUE' && (transferDetails['WOD_2__Transfer_Date__c'].trim() === '' || transferDetails['WOD_2__Transfer_Date__c'] > today)){
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                helper.showErrorToast(component, event, $A.get("$Label.c.RMTInventoryTransactionHistoryErrorCreationMessageTitle"), $A.get("$Label.c.BulkRMTTransferDateEmptyOrFuture"));
                showBatchSubmissionModal = false;
            }
        }
        if(showBatchSubmissionModal){
            helper.showBatchInsertModal(component, event, helper);
        }
    },
    
    handlesubmit: function (component, event, helper) {
        helper.showSpinner(component, event, 'bulkRMTTableSpinner');
        component.set('v.showSubmitButton',false);
        var transferDetails = component.get("v.transferDetails");
        var inventoryListingHeader = component.get("v.InventoryListingHeader");
        var result = component.get('v.selectedRows');
        console.log('---result-->'+JSON.stringify(result));
        var submittedRows = [];
        var objectFieldsAPINames = [];
        objectFieldsAPINames.push('WOD_2__To__c');
        var inventoryTransactionHistoryObjArray = [];
        var fieldListFromFieldSet = component.get("v.inventoryTransactionHistoryFieldsToShow");
        for (var i = 0; i < result.length; i++) {
            submittedRows.push(result[i].Id);
            var inventoryTransactionHistoryObj = {};
            inventoryTransactionHistoryObj['sobjectType'] = 'WOD_2__Inventory_Transaction_History__c';
            // Single RMT Inventory Transaction History Object Name Change.
            inventoryTransactionHistoryObj['Name'] = !!(component.get("v.recordId")) ? $A.get("$Label.c.RMTName") : $A.get("$Label.c.BulkRmtIthName");
            //inventoryTransactionHistoryObj['WOD_2__From__c'] = result[i].WOD_2__Account__c;
            inventoryTransactionHistoryObj['WOD_2__From__c'] =result[i]["WOD_2__Account__c"];
            inventoryTransactionHistoryObj['WOD_2__To__c'] = component.get("v.selectedDealer.Id");
            inventoryTransactionHistoryObj['WOD_2__Inventory__c'] = result[i].Id;
            inventoryTransactionHistoryObj['WOD_2__Transaction_Type__c'] = 'RMT';
            inventoryTransactionHistoryObj['WOD_2__Status__c'] = component.get('v.inventoryTransactionHistStatus')[0];
            // Extra fields other then the ones in the fieldset
            for (var count in fieldListFromFieldSet) {
                objectFieldsAPINames.push(fieldListFromFieldSet[count].name);
                inventoryTransactionHistoryObj[fieldListFromFieldSet[count].name] = transferDetails[fieldListFromFieldSet[count].name];
            }
            inventoryTransactionHistoryObjArray.push(inventoryTransactionHistoryObj); // Add to the List
        }
        helper.callApexController(component, "insertRMTTransaction",
                                  {
                                      'sObjectList': inventoryTransactionHistoryObjArray,
                                      'metadataForInventoryListingHeader': inventoryListingHeader,
                                      'fromObject': 'WOD_2__Inventory__c'
                                  }, true).then(function (insertResult) {
            if (insertResult['status'] === true) {
                var succesMessage;
                component.set("v.hideCheckBoxesOnTable",true);
                component.set("v.isSubmitted",true);
                if (insertResult.data) {
                    var insertionResult = JSON.parse(insertResult.data);
                    if(component.get("v.recordId") != null && component.get("v.recordId") != ''){
                        succesMessage = insertionResult.data[0].Message;
                        if(succesMessage == $A.get("$Label.c.BulkRMT_SuccessMessage")){
                            helper.showSuccessToast(component, event, '', $A.get("$Label.c.BulkRMT_SuccessMessage"));
                            helper.redirect(component,event,helper);
                        }
                    }
                    component.set("v.successRecordCount",insertionResult.successRecordsSize);
                    component.set("v.errorRecordCount",insertionResult.errorRecordsSize);
                    component.set("v.showResetButton",true);
                }
                helper.formUpdatedDataTableColumns(
                    component,
                    event,
                    helper,
                    insertionResult.columns,
                    insertionResult.data
                );
                component.set("v.readOnlyMode",true);
                // Single RMT Submit Toast Message Change.
                if(component.get("v.recordId") != null && component.get("v.recordId") != ''){
                    if(succesMessage != $A.get("$Label.c.BulkRMT_SuccessMessage")){
                        helper.showInfoToast(component, event, '', $A.get("$Label.c.RMT_SubmitMessage"));
                    }
                }else{
                    helper.showInfoToast(component, event, '', $A.get("$Label.c.BulkSubmitMessage"));
                }
                //  component.set("v.selectedRecords", result);
                component.set("v.showSubmitButton", false);
                helper.hideSpinner(component, event, 'bulkRMTTableSpinner');
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
            }
        }).catch(function (error) {
            helper.hideSpinner(component, event, 'bulkRMTTableSpinner');
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorMessage(component, event, helper, error);
        });
    },

    redirect: function (component, event, helper) {
        let navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": component.get("v.recordId"),
                "slideDevName": "related"
            });
            let datareccomp = component.find("datarecord");
            if(datareccomp)
            datareccomp.reloadRecord({ skipCache: true });
            $A.get("e.force:refreshView").fire();
            navEvt.fire();
    },

    fetchInventories: function (component, event, helper) {
        var namespace = component.get("v.namespace");
        component.set("v.batchInsert", false);
        helper.getDataTableColDataForConfigName(component, event, namespace + 'WOD_2__Inventory__c', component.get("v.InventoryListingHeader"),'left')
        .then($A.getCallback(function (response) {
            var fieldsWithAccessArray = [];
            var fieldsWithAccess = response.data;
            for (var i = 0; i < fieldsWithAccess.length; i++) {
                if (fieldsWithAccess[i].fieldName !== 'WOD_2__Account__r.Id') {
                    fieldsWithAccessArray.push(response.data[i]);
                }
            }
            component.set('v.inventoryTableColumnList', fieldsWithAccessArray);
            component.set("v.showTableonInitialLoad", true);
            // Single RMT whereClause change for BU Preselect.
            if(component.get("v.recordId") != null && component.get("v.recordId") != ''){
                component.set("v.whereClause", component.get("v.singleRecordWhereClause"));
            }
            var attributeObj = {
                'metadataName': component.get("v.InventoryListingHeader"),
                'whereClause': component.get("v.whereClause"),
                'fromObject': 'WOD_2__Inventory__c'
            };           
            return helper.callApexController(component, "fetchInventoryRecords", {
                fetchInventoriesInput: JSON.stringify(attributeObj)
            }, false);
            
        })).then($A.getCallback(function (response) {
            if (response.status === true) {
                var responsedata = JSON.parse(response.data);
                var datatableFields = responsedata.fields;
                var inventoryData = [];
                var dataObj = {};
                for (var i = 0; i < responsedata.data.length; i++) {
                    dataObj = {};
                    for (var j = 0; j < datatableFields.length; j++) {
                        dataObj[datatableFields[j]] = helper.getFieldValue(datatableFields[j], responsedata.data[i]);
                    }
                    inventoryData.push(dataObj);
                }
                // Single RMT Inventory List data table change.
                if(component.get("v.recordId") != null && component.get("v.recordId") != ''){
                    component.set("v.selectedRows", responsedata.data[0]);
                    component.set('v.inventoryRecordList', inventoryData);    
                }else{
                    component.set("v.selectedRows", []);
                    component.set('v.inventoryRecordList', inventoryData);    
                }                 
            } else {
                throw self.getErrorResponse(component, response.errormessage);
            }
            if(component.get("v.recordId") != null && component.get("v.recordId") != ''){
                component.set("v.showResetButton",false);  
                component.set('v.showSubmitButton',true);
            }           
        })).catch(function (error) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorMessage(component, event, helper, error);
        });
        
    },
    
    getDealerFieldDetails: function (component, event, helper) {
        helper.callApexController(component, "getDealerFieldDetails", {
            metadataRecordAPIName: component.get("v.newCustomerFieldsToShowMetadataName")
        }).then($A.getCallback(function (response) {
            if (response.data) {
                var responseData = JSON.parse(response.data);
                component.set("v.fieldlabelApiNameObjectList", responseData);
                helper.getMetadataMap(component, event, helper);
            }
        })).catch(function (error) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorMessage(component, event, helper, error);
        });
        
    },
    navigateToListHelper: function (component, event, helper, objectName, listName) {
        helper.callApexController(component, "queryInventoryObjects", { "objectName": objectName, "listName": listName }, false)            
        .then(function (queryResult) {
            if (queryResult['status'] === true) {
                var listId = JSON.parse(queryResult.data)[0].Id;
                if (listId !== undefined && listId !== null && listId !== "") {
                    var navEvent = $A.get("e.force:navigateToList");
                    navEvent.setParams({
                        "listViewId": listId,
                        "listViewName": null,
                        "scope": objectName
                    });
                    let datareccomp = component.find("datarecord");
                    if(datareccomp)
                    datareccomp.reloadRecord({ skipCache: true });
                    $A.get("e.force:refreshView").fire();
                    navEvent.fire();
                } else {
                    throw helper.getErrorResponse(component, $A.get("$Label.c.GenericErrorMessage"));
                }
            }
        }, false).catch(function (error) {
            helper.showErrorToast(component, event, '', $A.get("$Label.c.GenericErrorMessage"));
        });
    },
    
    getUserBus: function (component, event, helper) {
        helper.callApexController(component, "getCurrentUserBUValues", {"invId" : component.get("v.recordId")},false)            
        .then(function (response) {
            if (response['status'] === true) {
                var responseMap = JSON.parse(response.data);
                // Single RMT BU Select Changes
                if(!!responseMap.buList){
                    var buData = JSON.parse(responseMap.buList);
                    component.set("v.buOptions",buData);
                    // Defaulting  BU for the Bulk RMT if the Current User has only single BU assigned
                    if(buData.length == 1 && (component.get("v.recordId")== null||component.get("v.recordId")=='' || component.get("v.recordId") == undefined)){
                        component.set("v.selectedBUValue" ,buData[0]);
                        helper.handleBUchange(component,event,helper);
                    }
                }
                if(!!responseMap.whereClause){
                    component.set("v.singleRecordWhereClause",responseMap.whereClause);
                }
                if(!!responseMap.defaultBU){
                    component.set("v.selectedBUValue",responseMap.defaultBU);
                    helper.handleBUchange(component,event,helper);
                }
            }else{
                throw helper.getErrorResponse(component, response['message']);
            }
        }, false).catch(function (error) {
            helper.showErrorToast(component, event, '', error.errormessage);
        });
    },
    getConfigValues: function (component, event, helper) {
        //configurationSettingList
        helper.callApexController(component, "getCofigs",{ "configNames": JSON.stringify(component.get("v.configurationSettingList"))},false)            
        .then(function (response) {
            if (response['status'] === true) {
                var configData = JSON.parse(response.data);
                if(configData["IsAccountBusinessCategoryConfigUsed"] !== undefined){
                    var isTrueSet=false;
                    isTrueSet = (configData["IsAccountBusinessCategoryConfigUsed"].WOD_2__Configuration_Value__c == 'FALSE');
                    component.set("v.accountBUcheck", isTrueSet);
                }
            }else{
                throw helper.getErrorResponse(component, response['message']);
            }
        }, false).catch(function (error) {
            helper.showErrorToast(component, event, '', error);
        });
    },
    
    formUpdatedDataTableColumns: function (component, event, helper, fields, data) {
        var dateColumns = [];
        var supportedDatatypes = [
            "currency",
            "date",
            "email",
            "location",
            "number",
            "percent",
            "phone",
            "text",
            "url"
        ];
        var columns = [];
        for (var i = 0; i < fields.length; i++) {
            if(fields[i]["fieldpath"] !== 'WOD_2__Account__r.Id'){
                var column = {};
                column["label"] = fields[i]["label"];
                column["sortable"] = true;
                column["fieldName"] = fields[i]["fieldpath"];
                if (supportedDatatypes.indexOf(fields[i]["type"].toLowerCase()) === 1) {
                    if (fields[i]["type"].toLowerCase() === "date") {
                        dateColumns.push(fields[i]["fieldpath"]);
                        var timezone = $A.get("$Locale.timezone");
                        column["typeAttributes"] = {
                            timeZone: timezone
                        };
                    }
                    column["type"] = fields[i]["type"].toLowerCase();
                } else if (
                    fields[i]["type"].toLowerCase() === "double" ||
                    fields[i]["type"].toLowerCase() === "integer"
                ) {
                    var labelString = fields[i]["label"].toLowerCase();
                    if (labelString.includes("amount") || labelString.includes("cost")) {
                        column["type"] = "currency";
                        column["typeAttributes"] = {
                            currencyDisplayAs: "symbol",
                            currencyCode: "USD",
                            minimumFractionDigits: "2",
                            maximumFractionDigits: "2"
                        };
                    } else {
                        column["type"] = "number";
                    }
                } else if (fields[i]["type"].toLowerCase() === "boolean") {
                    column["type"] = "boolean";
                } else if (fields[i]["type"].toLowerCase() === "datetime") {
                    column["type"] = "date";
                    dateColumns.push(fields[i]["fieldpath"]);
                    var timezonenew = $A.get("$Locale.timezone");
                    column["typeAttributes"] = {
                        timeZone: timezonenew
                    };
                } else if (fields[i]["type"].toLowerCase() === "currency") {
                    column["type"] = "currency";
                    column["typeAttributes"] = {
                        currencyDisplayAs: "symbol",
                        currencyCode: "USD",
                        minimumFractionDigits: "2",
                        maximumFractionDigits: "2"
                    };
                } else {
                    column["type"] = "text";
                    column["wrapText"] = true; //wrapping text fields by default (TS-1234)
                }
                if (fields[i]["label"] === "Title") {
                    var colDatatypeAttributes = [];
                    var colDatatypeAttributesInnerArray = [];
                    column["fieldpath"] = fields[i]["fieldpath"] + "_url";
                    column["type"] = "url";
                    colDatatypeAttributesInnerArray["fieldName"] = fields[i]["fieldpath"];
                    colDatatypeAttributes["label"] = colDatatypeAttributesInnerArray;
                    column["typeAttributes"] = colDatatypeAttributes;
                    column["wrapText"] = true;
                }
                var colDatacellAttributes = [];
                column["cellAttributes"] = colDatacellAttributes;
                columns.push(column);
            }
        }
        if (dateColumns.length > 0) {
            for (var k = 0; k < data.length; k++) {
                for (var j = 0; j < dateColumns.length; j++) {
                    data[k][dateColumns[j]] = $A.localizationService.formatDate(
                        data[k][dateColumns[j]],
                        $A.get("$Locale.dateFormat")
                    );
                }
                data[k]["readonly"] = data[k]["readonly"] === "true" ? true : false;                
            }
        }
        component.set("v.inventoryTableColumnList", columns);
        component.set("v.inventoryRecordList", data);
        var queryBulderLWC = component.find('queryBuilderLWC');
        //added null check for queryBuilderLWC reset(TS-1010)
        if(!!queryBulderLWC){
           // queryBulderLWC.overrideRecordsAndColumns(data,columns);
        }
    },
    
    showBatchInsertModal: function (component, helper) {
        var msg = $A.get('$Label.c.BulkRMT_MoreThan') + " " + component.get('v.RMTRecordsLimit') + " " + $A.get('$Label.c.BulkRMT_BatchInsertWarningMsg');
        $A.createComponent("WOD_2:" + "ConfirmModelComponent", {
            header: $A.get('$Label.c.BulkRMT_BatchInsertWarningMsgHeader'),
            cancelLabel: $A.get('$Label.c.RMTBulkConfirmationCancel'),
            proceedLabel: $A.get('$Label.c.RMTBulkConfirmationProceed'),
            confirmMsg: msg,
            contextRecordId: 'createRMTTransaction',
            contextName: 'createRMTTransaction',
            modalHeight: '215',
            proceedPressed: component.getReference("v.batchInsertConfirmed")
        },
                           function (content, status, errorMessage) {
                               if (status === "SUCCESS") {
                                   component.set("v.batchInsert", true);
                                   component.find("overlayLib").showCustomModal({
                                       body: content,
                                       header: $A.get('$Label.c.BulkRMT_BatchInsertWarningMsgHeader'),
                                       showCloseButton: true,
                                       cssClass: "WOD_2BulkRMT_BaseComponent modalHeaderOverrideClass textHeadingOverrideClass"                                   })
                               }
                               else{
                                   console.log('error msg ****** ',errorMessage);
                                   
                               }
                           });
    } ,
    
    getMetadataMap: function (component, event, helper) {
        helper.callApexController(component, "fetchConfigurationSettingMetaDataMap", {
            metadataRecordAPINames: component.get("v.metadataNamesList")
        }).then(function (response) {
            if (response.data) {
                var responseData = JSON.parse(response.data);
                for (var metadata in responseData) {
                    if (metadata === 'BulkRMT_MaxInventoryRecordCount') {
                        if (responseData[metadata].WOD_2__isActive__c) {
                            var maxInventoriesPerPage = responseData[metadata].WOD_2__Configuration_Value__c;
                            component.set("v.RMTRecordsLimit", maxInventoriesPerPage);
                        }
                    } else if (metadata === 'BulkRMT_DefaultInventoryListView') {
                        if (responseData[metadata].WOD_2__isActive__c) {
                            var inventoryListView = responseData[metadata].WOD_2__Configuration_Value__c;
                            component.set("v.inventoryListView", inventoryListView);
                        }
                    } else if (metadata === 'BulkRMT_InventoryTxnHistoryStatus') {
                        if (responseData[metadata].WOD_2__isActive__c) {
                            //--Convert comma separated values to list and set
                            var fieldsToShowArray = responseData[metadata].WOD_2__Configuration_Value__c.split(',');
                            component.set("v.inventoryTransactionHistStatus", fieldsToShowArray);
                        }
                    }    
                }
                component.set("v.doneInit", true);
                
            } else {
                throw helper.getErrorResponse(component, $A.get("$Label.c.GenericErrorMessage"));
            }
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
        }).catch(function (error) {
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            helper.showErrorMessage(component, event, helper, error);
        });
    },
    // Single RMT BU change.
    handleBUchange: function (component, event, helper) {
        if(component.get("v.selectedBUValue") != ''){
            component.set("v.isBUselected",false);
            var action = component.get('c.handleClearSearchResults');
            $A.enqueueAction(action);
            return helper.callApexController(component, "getBusinessUnitConfigs", {
                businessCategoryConfigName : component.get("v.selectedBUValue"),
                bccsNameList : component.get("v.requiredBCCS")
            }).then($A.getCallback(function (response) {
                if (response.data) {
                    component.set("v.selectedDealerId" ,'');
                    var buWrap = JSON.parse(response.data)
                    var responseData = JSON.parse(buWrap.metaData);
                    var buObject = JSON.parse(buWrap.buObject);
                    component.set("v.selectedBU" ,buObject);
                    component.set("v.selectedBusinessUnit" ,buObject["Id"]);
                    var extraFilters = component.get("v.defaultInvenotryFilter")
                    extraFilters.WOD_2__Business_Unit__c = buObject["Id"];
                    component.set("v.additionalFilters",extraFilters);
                    for (var buConfig in responseData){
                        if(buConfig === 'BulkRMT_AccountDetailSharingSetting'){
                            component.set("v.accountDetailSharingSetting" , responseData[buConfig]);
                        } else if(buConfig === 'BulkRMT_AccountDetailColumnSize'){
                            component.set("v.accountDetailColumnSize" , responseData[buConfig]);
                        } else if(buConfig === 'BulkRMT_TransferDateMandatory'){
                            component.set("v.transferDateMandatory" , responseData[buConfig]);
                        } else if(buConfig === 'BulkRMT_CommentsMandatory'){
                            component.set("v.commentsMandatory" , responseData[buConfig]);
                        }else if (buConfig === 'BulkRMT_SearchAttributes') {
                            component.set("v.inventorySearchAttributesToShow", responseData[buConfig]);
                        } else if (buConfig === 'BulkRMT_InventoryHeaderFieldSet') {
                            component.set("v.InventoryListingHeader", responseData[buConfig]);
                        }else if (buConfig === 'BulkRMT_OverrideClassName') {
                            component.set("v.BulkRMTOverrideClass", responseData[buConfig]);
                        }  
                    }
                    component.set("v.isBUselected",true);
                    if(component.get("v.accountBUcheck")){
                        var extraParams = {
                            'WOD_2__Business_Units__c': component.get("v.selectedBUValue")
                        } 
                        component.set("v.extraParams",JSON.stringify(extraParams));
                    }else{
                        var extraParams = {
                            'WOD_2__Business_Category_Configuration__c': component.get("v.selectedBusinessUnit")
                        } 
                        component.set("v.extraParams",JSON.stringify(extraParams));
                    }
                }
                if(!!(component.get("v.recordId"))){
                    helper.fetchInventories(component,event,helper);
                }
            })).catch(function (error) {
                helper.hideSpinner(component, event, 'RMTBulkSpinner');
                component.set("v.isBUselected",false);
                component.set("v.selectedDealerId" ,'');
                var action = component.get('c.handleClearSearchResults');
                $A.enqueueAction(action);
                helper.showErrorMessage(component, event, helper, error);
            });
        }else{
            helper.hideSpinner(component, event, 'RMTBulkSpinner');
            component.set("v.isBUselected",false);
            component.set("v.selectedDealerId" ,'');
            var action = component.get('c.handleClearSearchResults');
            $A.enqueueAction(action);
        }
    }
})