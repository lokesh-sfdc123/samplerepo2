import { LightningElement, api, track } from 'lwc';
import QBRecordsEmpty from '@salesforce/label/c.QBRecordsEmpty';
export default class QbDataTableWebComponent extends LightningElement {
    LABELS = {
        'QBRecordsEmpty': QBRecordsEmpty
    }
    @api
    recordsData;
    @api
    headerColumns;
    @api
    hideCheckBoxes;
    @api
    noRecordsFound=false;
    

    handleRowSelection(event) {
        var selectedRecords = this.template.querySelector("lightning-datatable").getSelectedRows();
        const rowselectionevent = new CustomEvent('rowselectionevent', {
            detail: {
                "selectedRows":selectedRecords
            }
        });
        this.dispatchEvent(rowselectionevent);
    }

    @api
    clearRecords() {
        this.headerColumns = [];
        this.recordsData = [];
    }
    @api
    overrideRecordsAndColumns(records,columns) {
        this.headerColumns = columns;
        this.recordsData = records;
    }
}