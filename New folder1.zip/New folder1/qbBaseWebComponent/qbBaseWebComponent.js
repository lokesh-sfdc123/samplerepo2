import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import fetchRecords from '@salesforce/apex/QueryBuilderController.fetchRecords';
import getRecordCount from '@salesforce/apex/QueryBuilderController.getRecordCount';
import QBwhereClauseChange from '@salesforce/label/c.QBwhereClauseChange';
import QBConfirmationCancel from '@salesforce/label/c.QBConfirmationCancel';
import QBConfirmationProceed from '@salesforce/label/c.QBConfirmationProceed';
import QBConfirmationMessage from '@salesforce/label/c.QBConfirmationMessage';
import QB_SearchHeader from '@salesforce/label/c.QB_SearchHeader';
import QB_InventoryDetails from '@salesforce/label/c.QB_InventoryDetails';
import QBErrorCount from '@salesforce/label/c.QBErrorCount';
import QBSuccessCount from '@salesforce/label/c.QBSuccessCount';
import QBCriteriaBuilderHeader from '@salesforce/label/c.QBCriteriaBuilderHeader';


export default class QbBaseWebComponent extends LightningElement {
    LABELS = {
        'QBConfirmationCancel': QBConfirmationCancel,
        'QBwhereClauseChange': QBwhereClauseChange,
        'QBConfirmationProceed': QBConfirmationProceed,
        'QBConfirmationMessage': QBConfirmationMessage,
        'QB_SearchHeader': QB_SearchHeader,
        'QB_InventoryDetails': QB_InventoryDetails,
        'QBErrorCount': QBErrorCount,
        'QBSuccessCount': QBSuccessCount,
        'QBCriteriaBuilderHeader': QBCriteriaBuilderHeader
    }
    @api
    objectName;
    @api
    searchAttributes;
    @api
    buValue;
    @api
    listingHeader;
    @api
    hideSelectBoxes;
    @api
    successRecordCount = null;
    @api
    errorRecordCount = null;
    @api
    totalCount = null;
    @api
    displayDataEvenLimitExceeds = false;
    @api
    hideCriteriaBuilder;
    @api
    classOverrideName = 'QueryBuilderHandler';
    @api
    hideDataTable;
    @api
    searchResultThresholdLimit = null;
    @api
    additionalFilters = {};
    @api
    readOnlyMode = false;
    @track
    selectedRows = [];
    @api
    columns = [];
    @api
    records = [];
    @track
    actualData = [];
    @track
    invenotryFields = [];
    displyQBwarningModal = false;
    whereClause = '';
    recordsCount = 0;
    noRecordsFound = false;
    showSpinner = false;
    // Single RMT header change.
    get headerValue(){
        return this.objectName == 'WOD_2__Inventory__c'? this.LABELS.QB_InventoryDetails : this.LABELS.QB_SearchHeader;
    }

    initiatedQBsearchMethod(event) {
        debugger;
        if (this.whereClause !== event.detail["whereClause"] && event.detail["whereClause"] !== '') {
            this.whereClause = event.detail["whereClause"];
            this.handleWarningModal();
        } else {
            this.showToast(this.LABELS.QBwhereClauseChange, 'ERROR', 'error');
        }
    }

    handleWarningModal() {
        // Clear the selected list here
        let selectedRecords = this.selectedRows;
        if (selectedRecords !== undefined && selectedRecords !== null && selectedRecords !== '' && selectedRecords.length > 0) {
            this.showQBwarningModal();
        } else {
            this.getRecordsCount();
        }
    }

    showToast(message, title, variant) {
        const errorToastEvent = new ShowToastEvent({
            title: title,
            variant: variant,
            message: message
        });
        this.dispatchEvent(errorToastEvent);
    }

    modelResponse(event) {
        if (event.detail == 'ok') {
            this.closedQBwarningModal();
            this.records = [];
            this.fetchRecords();
        } else {
            this.closedQBwarningModal();
        }
    }

    showQBwarningModal() {
        this.displyQBwarningModal = true;
    }
    closedQBwarningModal() {
        this.displyQBwarningModal = false;
    }

    async getRecordsCount() {
        try {

            this.records = [];
            let attributeObj = {
                'metadataName': this.listingHeader,
                'whereClause': this.whereClause,
                'fromObject': this.objectName,
                'additionalParams': JSON.stringify(this.additionalFilters)
            };
            let result = await getRecordCount({ fetchRecordsInput: JSON.stringify(attributeObj), overrideClassName: this.classOverrideName });
            let response = result;
            if (response.status) {
                let responseWrapper = JSON.parse(response.data);
                let recordsCount = parseInt(responseWrapper.recordCount);
                let modifiedWhereClause = responseWrapper.whereClause;
                this.recordsCount = recordsCount;
                if (recordsCount == null || recordsCount == 0) {
                    this.noRecordsFound = true;
                } else {
                    this.noRecordsFound = false;
                }
                if (recordsCount != null && ((this.searchResultThresholdLimit != null && recordsCount < this.searchResultThresholdLimit) || this.displayDataEvenLimitExceeds)) {
                    this.fetchRecords(attributeObj);
                } else {
                    this.whereClause = modifiedWhereClause;
                    this.sendDatatoParentComponent([]);
                }
            } else {
                this.showToast(response.errormessage, 'ERROR', 'error');
            }

        } catch (error) {
            this.showToast(error, 'ERROR', 'error');
        }

    }



    async fetchRecords(attributeObj) {
        try {
            this.readOnlyMode = true;
            this.showSpinner = true;
            this.records = [];
            let result = await fetchRecords({ fetchRecordsInput: JSON.stringify(attributeObj), overrideClassName: this.classOverrideName });
            let response = result;
            if (response.status) {
                let resultData = JSON.parse(response.data);
                this.invenotryFields = resultData.fields;
                if (resultData.data.length != null && ((this.searchResultThresholdLimit != null && resultData.data.length < this.searchResultThresholdLimit) || this.displayDataEvenLimitExceeds)) {
                    this.prepareRecords(resultData);
                } else {
                    this.showSpinner=false;
                    this.sendDatatoParentComponent(resultData.data);
                }
            } else {
                this.showToast(response.errormessage, 'ERROR', 'error');
                this.readOnlyMode=false;
                this.showSpinner = false;
            }

        } catch (error) {
            this.showToast(error, 'ERROR', 'error');
            this.readOnlyMode=false;
            this.showSpinner = false;
        }

    }
    sendDatatoParentComponent(records) {
        const value = {
            'whereClause': this.whereClause,
            'recordsLength': this.recordsCount,
            'records': JSON.stringify(records),
            'columns': this.columns,
            'invFields': this.invenotryFields,
        };
        const searchinitialized = new CustomEvent('searchinitialized', {
            detail: { value }
        });
        this.dispatchEvent(searchinitialized);
    }
    prepareRecords(Responsedata) {
        debugger;
        let objectData = [];
        this.actualData = Responsedata.data;
        for (let eachRecord = 0; eachRecord < Responsedata.data.length; eachRecord++) {
            let columns = [];
            let eachDataRec = {};
            for (let i = 0; i < Responsedata.fields.length; i++) {
                if (Responsedata.fields[i] != 'Id') {
                    let label;
                    let fieldname;
                    if (Responsedata.fields[i].includes("__r.")) {
                        label = Responsedata.labels[i];
                        fieldname = Responsedata.fields[i].replace("__r.", "");
                        let reference = Responsedata.fields[i].split(".");
                        let parentId = Responsedata.data[eachRecord][reference[0].replace("__r", "__c")];
                        eachDataRec[reference[0].replace("__r", "__c")] = parentId
                        let finalRefField = '';
                        for (let j = 0; j < reference.length; j++) {
                            if (j == 0) {
                                finalRefField = Responsedata.data[eachRecord][reference[j]]
                            } else {
                                finalRefField = finalRefField[reference[j]];
                            }
                        }
                        eachDataRec[fieldname] = finalRefField;
                    } else {
                        label = Responsedata.labels[i];
                        fieldname = Responsedata.fields[i];
                        eachDataRec[fieldname] = Responsedata.data[eachRecord][Responsedata.fields[i]];
                    }

                    columns.push({
                        "label": label, "fieldName": fieldname
                    });
                } else {
                    eachDataRec["Id"] = Responsedata.data[eachRecord]["Id"];
                }
            }
            this.columns = columns;
            objectData.push(eachDataRec);
        }
        this.records = objectData;
        this.readOnlyMode=false;
        this.showSpinner = false;
        this.sendDatatoParentComponent(this.records);

    }
    handleOnRowSelection(event) {
        let rowSelected = event.detail["selectedRows"];
        let finalRows = [];
        for (let i = 0; i < rowSelected.length; i++) {
            for (let j = 0; j < this.actualData.length; j++) {
                if (rowSelected[i]["Id"] == this.actualData[j]["Id"]) {
                    finalRows.push(this.actualData[j]);
                    break;
                }
            }
        }
        this.selectedRows = finalRows;
        const value = finalRows;
        const selectrows = new CustomEvent('selectrows', {
            detail: { value }
        });
        this.dispatchEvent(selectrows);
    }

    get showTableComponent() {
        return this.records.length > 0 || this.noRecordsFound;
    }
    get showErrorAndSuccessCount() {
        let flag = false;
        if (this.successRecordCount != null && this.errorRecordCount != null && this.totalCount != null) {
            flag = true;
        }
        return flag;
    }
    @api
    handleResetSearchResult() {
        this.records = [];
        this.columns = [];
        this.whereClause = '';
        this.filterCriteria = [];
        this.filterLogic = '';
        this.template.querySelector('c-qb-query-builder-web-component').resetData();
    }

    @api
    clearRecords() {
        this.template.querySelector('c-qb-data-table-web-component').clearRecords();
    }
    @api
    overrideRecordsAndColumns(records, columns) {
        this.template.querySelector('c-qb-data-table-web-component').overrideRecordsAndColumns(records, columns);
    }
}